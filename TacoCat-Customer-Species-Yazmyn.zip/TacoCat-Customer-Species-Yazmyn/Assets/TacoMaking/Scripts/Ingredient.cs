using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ingredient : MonoBehaviour
{
    [Tooltip("sometimes i want a taco where the tortilla is just filled with more torilla")]
    public ingredientType type;
}
